library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity snake_game_tb is
-- Testbench nemá porty
end snake_game_tb;

architecture Behavioral of snake_game_tb is

    -- Komponenta, kterou testujeme (UUT - Unit Under Test)
    component nexys_a7_snake_top
        Port (
            CLK100MHZ : in  STD_LOGIC;
            BTNC      : in  STD_LOGIC;
            BTNU      : in  STD_LOGIC;
            BTND      : in  STD_LOGIC;
            BTNL      : in  STD_LOGIC;
            BTNR      : in  STD_LOGIC;
            SEG       : out STD_LOGIC_VECTOR (7 downto 0);
            AN        : out STD_LOGIC_VECTOR (7 downto 0);
            LED       : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    -- Signály pro propojení s UUT
    signal clk   : std_logic := '0';
    signal btnc  : std_logic := '0';
    signal btnu  : std_logic := '0';
    signal btnd  : std_logic := '0';
    signal btnl  : std_logic := '0';
    signal btnr  : std_logic := '0';
    signal seg   : std_logic_vector(7 downto 0);
    signal an    : std_logic_vector(7 downto 0);
    signal led   : std_logic_vector(15 downto 0);

    -- Definice periody hodin (10 ns = 100 MHz)
    constant CLK_PERIOD : time := 10 ns;

begin

    -- Instanciace Top modulu
    uut: nexys_a7_snake_top
        port map (
            CLK100MHZ => clk,
            BTNC      => btnc,
            BTNU      => btnu,
            BTND      => btnd,
            BTNL      => btnl,
            BTNR      => btnr,
            SEG       => seg,
            AN        => an,
            LED       => led
        );

    -- Generátor hodin
    clk_process : process
    begin
        clk <= '0';
        wait for CLK_PERIOD/2;
        clk <= '1';
        wait for CLK_PERIOD/2;
    end process;

    -- Stimulační proces (vlastní testování)
    stim_proc: process
    begin		
        -- 1. Reset systému
        btnc <= '1';
        wait for 100 ns;
        btnc <= '0';
        wait for 1 ms; -- Počkáme, až se stabilizuje debouncer

        -- 2. Start hry stisknutím tlačítka Nahoru
        -- POZOR: Debouncer v kódu má limit 10ms, v simulaci 
        -- bychom museli čekat dlouho, nebo limit pro simulaci snížit.
        btnu <= '1';
        wait for 15 ms; 
        btnu <= '0';

        -- 3. Necháme hada chvíli lézt doprava (výchozí směr)
        -- V simulaci uvidíme, jak se mění signály AN a SEG (multiplexování)
        wait for 100 ms;

        -- 4. Změna směru dolů
        btnd <= '1';
        wait for 15 ms;
        btnd <= '0';

        -- 5. Simulace "sežrání" (v testbenchi těžko ovlivníme náhodu, 
        -- ale můžeme sledovat, zda se po dlouhé době rozsvítí další LED skóre)
        wait for 500 ms;

        -- Ukončení simulace
        report "Simulace dokoncena";
        wait;
    end process;

end Behavioral;