library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity debouncer is
    Generic (
        DEBOUNCE_LIMIT : integer := 1000000 -- 10ms at 100MHz
    );
    Port (
        clk     : in  STD_LOGIC;
        rst     : in  STD_LOGIC;
        switch_in : in  STD_LOGIC;
        switch_out: out STD_LOGIC
    );
end debouncer;

architecture Behavioral of debouncer is
    signal count : integer range 0 to DEBOUNCE_LIMIT := 0;
    signal state : std_logic := '0';
begin
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                count <= 0;
                state <= switch_in;
            elsif switch_in /= state then
                if count < DEBOUNCE_LIMIT then
                    count <= count + 1;
                else
                    state <= switch_in;
                    count <= 0;
                end if;
            else
                count <= 0;
            end if;
        end if;
    end process;
    switch_out <= state;
end Behavioral;