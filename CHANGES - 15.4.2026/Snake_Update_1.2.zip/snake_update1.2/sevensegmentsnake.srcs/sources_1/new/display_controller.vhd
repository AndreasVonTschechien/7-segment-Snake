library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity display_controller is
    Port (
        clk : in STD_LOGIC;
        video_in : in STD_LOGIC_VECTOR(63 downto 0);
        seg_out : out STD_LOGIC_VECTOR(7 downto 0);
        an_out : out STD_LOGIC_VECTOR(7 downto 0)
    );
end display_controller;

architecture Behavioral of display_controller is
    signal refresh_cnt : unsigned(16 downto 0) := (others => '0');
    signal sel : integer range 0 to 7;
begin
    process(clk) begin
        if rising_edge(clk) then refresh_cnt <= refresh_cnt + 1; end if;
    end process;
    
    sel <= to_integer(refresh_cnt(16 downto 14));

    process(sel, video_in) begin
        an_out <= (others => '1');
        an_out(sel) <= '0';
        seg_out <= not video_in(sel*8+7 downto sel*8); -- Katody jsou active LOW
    end process;
end Behavioral;