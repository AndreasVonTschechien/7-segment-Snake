library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top_snake is
    Port (
        CLK100MHZ : in STD_LOGIC;
        BTNC, BTNU, BTND, BTNL, BTNR : in STD_LOGIC;
        SEG : out STD_LOGIC_VECTOR(7 downto 0);
        AN : out STD_LOGIC_VECTOR(7 downto 0);
        LED : out STD_LOGIC_VECTOR(15 downto 0)
    );
end top_snake;

architecture Arch of top_snake is
    signal video : std_logic_vector(63 downto 0);
begin
    G: entity work.snake_game port map(
        clk => CLK100MHZ, rst => BTNC,
        btn_u => BTNU, btn_d => BTND, btn_l => BTNL, btn_r => BTNR,
        seg_data => video, led_score => LED
    );
    D: entity work.display_controller port map(
        clk => CLK100MHZ, video_in => video, seg_out => SEG, an_out => AN
    );
end Arch;