library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity snake_game is
    Port (
        clk : in STD_LOGIC;
        rst : in STD_LOGIC; -- BTNC
        btn_u, btn_d, btn_l, btn_r : in STD_LOGIC;
        seg_data : out STD_LOGIC_VECTOR(63 downto 0);
        led_score : out STD_LOGIC_VECTOR(15 downto 0)
    );
end snake_game;

architecture Behavioral of snake_game is
    -- Pozice hada: X (displej 0-7), Y (řada 0=A, 1=G, 2=D)
    type pos_array is array (0 to 15) of integer range 0 to 7;
    type y_array is array (0 to 15) of integer range 0 to 2;
    
    signal sn_x : pos_array := (3, 2, 1, others => 0);
    signal sn_y : y_array := (1, 1, 1, others => 0);
    signal sn_len : integer range 1 to 16 := 3;
    
    signal food_x : integer range 0 to 7 := 5;
    signal food_y : integer range 0 to 2 := 1;
    
    -- Směry: 0:Up, 1:Down, 2:Left, 3:Right
    signal dir : integer range 0 to 3 := 3;
    signal move_cnt : integer := 0;
    signal score : integer range 0 to 15 := 0;
    signal game_active : std_logic := '0';

begin
    -- 1. Detekce směru
    process(clk) begin
        if rising_edge(clk) then
            if rst = '1' then 
                dir <= 3;
                game_active <= '0';
            else
                -- Hra začne až po stisknutí libovolného směru
                if btn_u = '1' and dir /= 1 then dir <= 0; game_active <= '1'; end if;
                if btn_d = '1' and dir /= 0 then dir <= 1; game_active <= '1'; end if;
                if btn_r = '1' and dir /= 3 then dir <= 2; game_active <= '1'; end if;
                if btn_l = '1' and dir /= 2 then dir <= 3; game_active <= '1'; end if;
            end if;
        end if;
    end process;

    -- 2. Pohyb hada
    process(clk)
        variable nx : integer;
        variable ny : integer;
    begin
        if rising_edge(clk) then
            if rst = '1' then
                move_cnt <= 0; sn_len <= 3; score <= 0;
                sn_x <= (3, 2, 1, others => 0);
                sn_y <= (1, 1, 1, others => 0);
            elsif game_active = '1' then
                if move_cnt < 20000000 then -- Rychlost cca 5 Hz
                    move_cnt <= move_cnt + 1;
                else
                    move_cnt <= 0;
                    nx := sn_x(0); ny := sn_y(0);
                    
                    case dir is
                        when 0 => if ny = 0 then ny := 2; else ny := ny - 1; end if; -- UP
                        when 1 => if ny = 2 then ny := 0; else ny := ny + 1; end if; -- DOWN
                        when 2 => if nx = 0 then nx := 7; else nx := nx - 1; end if; -- LEFT
                        when 3 => if nx = 7 then nx := 0; else nx := nx + 1; end if; -- RIGHT
                    end case;

                    -- Žrádlo
                    if nx = food_x and ny = food_y then
                        if sn_len < 15 then sn_len <= sn_len + 1; end if;
                        score <= score + 1;
                        food_x <= (food_x + 3) mod 8;
                        food_y <= (food_y + 1) mod 3;
                    end if;

                    -- Posun těla
                    for i in 15 downto 1 loop
                        sn_x(i) <= sn_x(i-1);
                        sn_y(i) <= sn_y(i-1);
                    end loop;
                    sn_x(0) <= nx; sn_y(0) <= ny;
                end if;
            end if;
        end if;
    end process;

    -- 3. Zobrazení (OPRAVENO: Striktně vždy jen 1 segment)
    process(sn_x, sn_y, sn_len, food_x, food_y, dir)
        variable v : std_logic_vector(63 downto 0);
        variable base_seg : integer;
    begin
        v := (others => '0');
        
        -- Vykreslení jídla (vždy na segmentu G, aby bylo uprostřed)
        if food_y = 0 then
            v(food_x*8 + 0) := '1';
        elsif food_y = 1 then
            v(food_x*8 + 6) := '1';
        else
            v(food_x*8 + 3) := '1';
        end if;

        -- Vykreslení hada
        for i in 0 to 15 loop
            if i < sn_len then
                -- Pokud se had hýbe Nahoru/Dolů NEBO Doleva/Doprava, 
                -- používáme vždy jen hlavní vodorovné linky (A, G, D), 
                -- aby tělo tvořilo souvislou čáru a nevznikaly patvary.
                case sn_y(i) is
                    when 0 => base_seg := 0; -- Segment A (Vrch)
                    when 1 => base_seg := 6; -- Segment G (Střed)
                    when 2 => base_seg := 3; -- Segment D (Spodek)
                end case;
                
                v(sn_x(i)*8 + base_seg) := '1';
            end if;
        end loop;
        seg_data <= v;
    end process;

    led_score <= std_logic_vector(to_unsigned(score, 16));
end Behavioral;