library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity snake_top is
    port (
        clk   : in  std_logic;
        btnc  : in  std_logic; -- Reset
        btnu  : in  std_logic; -- Up
        btnd  : in  std_logic; -- Down
        btnl  : in  std_logic; -- Left (ovládá pohyb DOPRAVA)
        btnr  : in  std_logic; -- Right (ovládá pohyb DOLEVA)
        seg   : out std_logic_vector(6 downto 0); -- A, B, C, D, E, F, G (aktivní v 0)
        an    : out std_logic_vector(7 downto 0); -- Anody (aktivní v 0)
        led   : out std_logic_vector(15 downto 0) -- Skóre
    );
end entity snake_top;

architecture Behavioral of snake_top is

    -- Typy pro hada (max délka 32 segmentů)
    -- NYNÍ 16 SLOUPCŮ: x = 0 až 15
    type t_coord_x is array (0 to 31) of integer range 0 to 15;
    type t_coord_y is array (0 to 31) of integer range 0 to 4; -- 0:A, 1:F/B, 2:G, 3:E/C, 4:D

    -- Had začíná pouze s 1 dílkem na pozici x=7, y=4 (pravá strana 3. displeje, spodní segment D)
    signal snake_x : t_coord_x := (0 => 7, others => 0);
    signal snake_y : t_coord_y := (0 => 4, others => 0);
    signal snake_len : integer range 1 to 32 := 1;
    
    signal food_x : integer range 0 to 15 := 10;
    signal food_y : integer range 0 to 4 := 0;

    -- Signály pro komponenty
    signal sig_ce_mux  : std_logic;
    signal sig_ce_game : std_logic;
    signal sig_mux_cnt : std_logic_vector(2 downto 0);
    signal sig_btn_u, sig_btn_d, sig_btn_l, sig_btn_r, sig_btn_c : std_logic;
    
    -- Směr: 0:Up, 1:Down, 2:Left, 3:Right
    signal sig_dir : integer range 0 to 3 := 0;
    signal sig_game_over : std_logic := '0';
    signal sig_rand : unsigned(15 downto 0) := x"ACE1"; -- LFSR pro náhodu

begin

    ----------------------------------------------------------------
    -- 1. Instanciace modulů (clk_en, counter, debounce)
    ----------------------------------------------------------------
    clk_en_mux : entity work.clk_en 
        generic map(G_MAX => 100000) 
        port map(clk=>clk, rst=>btnc, ce=>sig_ce_mux);

    -- Zpomalení hry (50 000 000 = posun každých 0.5 vteřiny)
    clk_en_game : entity work.clk_en 
        generic map(G_MAX => 50000000) 
        port map(clk=>clk, rst=>btnc, ce=>sig_ce_game);

    mux_counter : entity work.counter 
        generic map(G_BITS => 3) 
        port map(clk=>clk, rst=>btnc, en=>sig_ce_mux, cnt=>sig_mux_cnt);

    deb_u : entity work.debounce port map(clk=>clk, rst=>'0', btn_in=>btnu, btn_press=>sig_btn_u);
    deb_d : entity work.debounce port map(clk=>clk, rst=>'0', btn_in=>btnd, btn_press=>sig_btn_d);
    
    -- Prohozená tlačítka
    deb_l : entity work.debounce port map(clk=>clk, rst=>'0', btn_in=>btnl, btn_press=>sig_btn_r);
    deb_r : entity work.debounce port map(clk=>clk, rst=>'0', btn_in=>btnr, btn_press=>sig_btn_l);
    
    deb_c : entity work.debounce port map(clk=>clk, rst=>'0', btn_in=>btnc, btn_press=>sig_btn_c);

    ----------------------------------------------------------------
    -- 2. Herní logika
    ----------------------------------------------------------------
    p_game : process(clk)
        variable next_x : integer range 0 to 15;
        variable next_y : integer range 0 to 4;
    begin
        if rising_edge(clk) then
            -- LFSR pro generování náhodné pozice potravy
            sig_rand <= sig_rand(14 downto 0) & (sig_rand(15) xor sig_rand(13) xor sig_rand(12) xor sig_rand(10));

            -- Synchronní reset celé hry
            if sig_btn_c = '1' then
                snake_len <= 1;
                snake_x(0) <= 7;
                snake_y(0) <= 4;
                sig_game_over <= '0';
                sig_dir <= 0;
            
            -- Běh hry
            elsif sig_game_over = '0' then
                
                if sig_btn_u = '1' and sig_dir /= 1 then sig_dir <= 0; end if;
                if sig_btn_d = '1' and sig_dir /= 0 then sig_dir <= 1; end if;
                -- Odbočit do boku lze pouze, pokud je had zrovna na horizontálním segmentu (A, G nebo D)
                if sig_btn_l = '1' and sig_dir /= 3 and (snake_y(0)=0 or snake_y(0)=2 or snake_y(0)=4) then sig_dir <= 2; end if;
                if sig_btn_r = '1' and sig_dir /= 2 and (snake_y(0)=0 or snake_y(0)=2 or snake_y(0)=4) then sig_dir <= 3; end if;

                -- Herní tik (pohyb)
                if sig_ce_game = '1' then
                    next_x := snake_x(0);
                    next_y := snake_y(0);

                    case sig_dir is
                        when 0 => -- Nahoru
                            if next_y = 0 then next_y := 4; else next_y := next_y - 1; end if;
                        when 1 => -- Dolů
                            if next_y = 4 then next_y := 0; else next_y := next_y + 1; end if;
                        when 2 => -- Doleva
                            if next_x = 0 then next_x := 15; else next_x := next_x - 1; end if;
                        when 3 => -- Doprava
                            if next_x = 15 then next_x := 0; else next_x := next_x + 1; end if;
                    end case;

                    -- Detekce kolize
                    for i in 1 to 31 loop
                        if i < snake_len and next_x = snake_x(i) and next_y = snake_y(i) then
                            sig_game_over <= '1';
                        end if;
                    end loop;

                    -- Snězení potravy
                    if next_x = food_x and next_y = food_y then
                        if snake_len < 32 then 
                            snake_len <= snake_len + 1; 
                        end if;
                        food_x <= to_integer(sig_rand(3 downto 0));
                        food_y <= to_integer(sig_rand(7 downto 4)) rem 5;
                    end if;

                    -- Posun těla
                    for i in 31 downto 1 loop
                        snake_x(i) <= snake_x(i-1);
                        snake_y(i) <= snake_y(i-1);
                    end loop;
                    
                    -- Zápis nové hlavy
                    snake_x(0) <= next_x;
                    snake_y(0) <= next_y;
                end if;
            end if;
        end if;
    end process p_game;

    ----------------------------------------------------------------
    -- 3. Zobrazení na 7-segmentu
    ----------------------------------------------------------------
    p_mux : process(sig_mux_cnt, snake_x, snake_y, snake_len, food_x, food_y)
        variable v_seg : std_logic_vector(6 downto 0);
        variable v_idx : integer;
    begin
        v_idx := to_integer(unsigned(sig_mux_cnt));
        v_seg := "1111111";

        -- Vykreslení těla hada
        for i in 0 to 31 loop
            if i < snake_len and (snake_x(i) / 2) = v_idx then
                if (snake_x(i) mod 2) = 0 then
                    -- Had je na LEVÉ polovině displeje
                    case snake_y(i) is
                        when 0 => v_seg(0) := '0'; -- A
                        when 1 => v_seg(5) := '0'; -- F 
                        when 2 => v_seg(6) := '0'; -- G
                        when 3 => v_seg(4) := '0'; -- E 
                        when 4 => v_seg(3) := '0'; -- D
                    end case;
                else
                    -- Had je na PRAVÉ polovině displeje
                    case snake_y(i) is
                        when 0 => v_seg(0) := '0'; -- A
                        when 1 => v_seg(1) := '0'; -- B 
                        when 2 => v_seg(6) := '0'; -- G
                        when 3 => v_seg(2) := '0'; -- C 
                        when 4 => v_seg(3) := '0'; -- D
                    end case;
                end if;
            end if;
        end loop;

        -- Vykreslení potravy
        if (food_x / 2) = v_idx then
            if (food_x mod 2) = 0 then
                case food_y is
                    when 0 => v_seg(0) := '0';
                    when 1 => v_seg(5) := '0'; -- F
                    when 2 => v_seg(6) := '0';
                    when 3 => v_seg(4) := '0'; -- E
                    when 4 => v_seg(3) := '0';
                end case;
            else
                case food_y is
                    when 0 => v_seg(0) := '0';
                    when 1 => v_seg(1) := '0'; -- B
                    when 2 => v_seg(6) := '0';
                    when 3 => v_seg(2) := '0'; -- C
                    when 4 => v_seg(3) := '0';
                end case;
            end if;
        end if;

        an <= (others => '1');
        an(v_idx) <= '0';
        seg <= v_seg;
    end process p_mux;

    ----------------------------------------------------------------
    -- 4. Skóre na LED
    ----------------------------------------------------------------
    p_score : process(snake_len)
    begin
        led <= (others => '0');
        for i in 0 to 15 loop
            -- Bod se přičte za každou hodnotu délky nad 1
            if i < (snake_len - 1) then 
                led(i) <= '1'; 
            end if;
        end loop;
    end process p_score;

end architecture Behavioral;