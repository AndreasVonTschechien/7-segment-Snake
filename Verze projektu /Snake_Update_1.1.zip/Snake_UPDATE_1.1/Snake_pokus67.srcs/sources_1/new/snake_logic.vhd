
-- K LOGICE HADA BYLO VYUŽITO AI

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity snake_logic is
    Port ( 
        clk        : in  STD_LOGIC;
        rst        : in  STD_LOGIC;
        ce_move    : in  STD_LOGIC; -- Impuls pro pohyb (např. 4Hz)
        up_p       : in  STD_LOGIC; -- Pulzy z debouncerů pro změnu směru
        down_p     : in  STD_LOGIC;
        left_p     : in  STD_LOGIC;
        right_p    : in  STD_LOGIC;
        seg_o      : out STD_LOGIC_VECTOR(6 downto 0)
    );
end snake_logic;

architecture Behavioral of snake_logic is
    type t_dir is (DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT, DIR_STOP);
    signal sig_dir : t_dir := DIR_STOP;
    signal sig_pos : integer range 0 to 6 := 6; -- Start na segmentu G
begin
    -- Proces pro změnu směru (reaguje okamžitě na stisk tlačítka)
    p_direction : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                sig_dir <= DIR_STOP;
            else
                if up_p = '1'    then sig_dir <= DIR_UP;
                elsif down_p = '1'  then sig_dir <= DIR_DOWN;
                elsif left_p = '1'  then sig_dir <= DIR_LEFT;
                elsif right_p = '1' then sig_dir <= DIR_RIGHT;
                end if;
            end if;
        end if;
    end process;

    -- Proces pro samotný pohyb (reaguje pouze na ce_move)
    p_movement : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                sig_pos <= 6;
            elsif ce_move = '1' then
                case sig_pos is
                    when 0 => -- Segment A
                        if sig_dir = DIR_LEFT then sig_pos <= 5;
                        elsif sig_dir = DIR_RIGHT then sig_pos <= 1; end if;
                    when 5 => -- Segment F
                        if sig_dir = DIR_UP then sig_pos <= 0;
                        elsif sig_dir = DIR_DOWN then sig_pos <= 4;
                        elsif sig_dir = DIR_RIGHT then sig_pos <= 6; end if;
                    when 4 => -- Segment E
                        if sig_dir = DIR_UP then sig_pos <= 5;
                        elsif sig_dir = DIR_DOWN then sig_pos <= 3;
                        elsif sig_dir = DIR_RIGHT then sig_pos <= 6; end if;
                    when 3 => -- Segment D
                        if sig_dir = DIR_LEFT then sig_pos <= 4;
                        elsif sig_dir = DIR_RIGHT then sig_pos <= 2; end if;
                    when 2 => -- Segment C
                        if sig_dir = DIR_UP then sig_pos <= 1;
                        elsif sig_dir = DIR_DOWN then sig_pos <= 3;
                        elsif sig_dir = DIR_LEFT then sig_pos <= 6; end if;
                    when 1 => -- Segment B
                        if sig_dir = DIR_UP then sig_pos <= 0;
                        elsif sig_dir = DIR_DOWN then sig_pos <= 2;
                        elsif sig_dir = DIR_LEFT then sig_pos <= 6; end if;
                    when 6 => -- Segment G
                        if sig_dir = DIR_LEFT then sig_pos <= 5;
                        elsif sig_dir = DIR_RIGHT then sig_pos <= 1; end if;
                    when others => null;
                end case;
            end if;
        end if;
    end process;

    -- Dekodér (stejný jako dříve)
    with sig_pos select
        seg_o <= "1000000" when 0, "0100000" when 1, "0010000" when 2,
                 "0001000" when 3, "0000100" when 4, "0000010" when 5,
                 "0000001" when 6, "0000000" when others;
end Behavioral;