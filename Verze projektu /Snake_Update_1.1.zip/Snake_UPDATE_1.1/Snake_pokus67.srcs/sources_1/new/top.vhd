library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top is
    Port ( 
        CLK100MHZ : in  STD_LOGIC;
        BTNU, BTND, BTNL, BTNR, BTNC : in  STD_LOGIC; -- Center je Reset
        CA, CB, CC, CD, CE, CF, CG : out STD_LOGIC    -- Výstupy na displej
    );
end top;

-- ... (entity top zůstává stejná) ...

architecture Behavioral of top is
    signal s_up, s_down, s_left, s_right : std_logic;
    signal s_ce_move : std_logic;
    signal s_seg : std_logic_vector(6 downto 0);
begin
    -- Instance pro rychlost pohybu hada (4 Hz při 100 MHz hodinách)
    -- G_MAX = 100 000 000 / 4 = 25 000 000
    clk_en_move : entity work.clk_en
        generic map ( G_MAX => 25_000_000 ) 
        port map ( clk => CLK100MHZ, rst => BTNC, ce => s_ce_move );

    -- Debouncery pro tlačítka (využívají vnitřní clk_en pro 2ms vzorkování)
    deb_u: entity work.debounce port map (CLK100MHZ, BTNC, BTNU, open, s_up, open);
    deb_d: entity work.debounce port map (CLK100MHZ, BTNC, BTND, open, s_down, open);
    deb_l: entity work.debounce port map (CLK100MHZ, BTNC, BTNL, open, s_left, open);
    deb_r: entity work.debounce port map (CLK100MHZ, BTNC, BTNR, open, s_right, open);

    -- Logika s automatickým pohybem
    snake_inst : entity work.snake_logic
        port map (
            clk      => CLK100MHZ,
            rst      => BTNC,
            ce_move  => s_ce_move, -- Had se pohne každých 250 ms
            up_p     => s_up,
            down_p   => s_down,
            left_p   => s_left,
            right_p  => s_right,
            seg_o    => s_seg
        );

    -- Výstupy na piny (aktivní nízká pro Nexys)
    CA <= not s_seg(6); CB <= not s_seg(5); CC <= not s_seg(4); 
    CD <= not s_seg(3); CE <= not s_seg(2); CF <= not s_seg(1); CG <= not s_seg(0);
end Behavioral;