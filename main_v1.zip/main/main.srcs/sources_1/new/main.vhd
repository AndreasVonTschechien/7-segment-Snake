library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity main is
    Port ( clk : in STD_LOGIC;
           ce : in STD_LOGIC;
           rst : in STD_LOGIC;
           btn_up : in STD_LOGIC;
           btn_down : in STD_LOGIC;
           btn_right : in STD_LOGIC;
           btn_left : in STD_LOGIC);
end main;

architecture Behavioral of main is

    component clk_en is
        generic ( G_MAX : positive );
        port (
            clk : in  std_logic;
            rst : in  std_logic;
            ce  : out std_logic
        );
    end component clk_en;
    
    component debounce is
        port ( clk : in std_logic;
            rst : in std_logic;
            btn_in : in std_logic;
            btn_state : out std_logic;
            btn_press : out std_logic;
            btn_release: out std_logic);
    end component debounce;
    
    signal sig_press_up : std_logic;
    signal sig_press_down : std_logic;
    signal sig_press_right : std_logic;
    signal sig_press_left : std_logic;
    
begin

    debounce_0 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_up,
            btn_press => sig_press_up
        );

    debounce_1 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_down,
            btn_press => sig_press_down
        );

    debounce_2 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_right,
            btn_press => sig_press_right
        );
        
    debounce_3 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_left,
            btn_press => sig_press_left
        );
        
end Behavioral;