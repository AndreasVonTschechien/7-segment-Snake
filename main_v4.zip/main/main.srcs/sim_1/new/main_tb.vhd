library ieee;
use ieee.std_logic_1164.all;

entity tb_main is
end tb_main;

architecture tb of tb_main is

    component main
        port (clk       : in std_logic;
              rst       : in std_logic;
              btn_up    : in std_logic;
              btn_down  : in std_logic;
              btn_right : in std_logic;
              btn_left  : in std_logic);
    end component;

    signal clk       : std_logic;
    signal rst       : std_logic;
    signal btn_up    : std_logic;
    signal btn_down  : std_logic;
    signal btn_right : std_logic;
    signal btn_left  : std_logic;

    constant TbPeriod : time := 2 ns; -- ***EDIT*** Put right period here
    signal TbClock : std_logic := '0';
    signal TbSimEnded : std_logic := '0';

begin

    dut : main
    port map (clk       => clk,
              rst       => rst,
              btn_up    => btn_up,
              btn_down  => btn_down,
              btn_right => btn_right,
              btn_left  => btn_left);

    -- Clock generation
    TbClock <= not TbClock after TbPeriod/2 when TbSimEnded /= '1' else '0';

    -- ***EDIT*** Check that clk is really your main clock signal
    clk <= TbClock;

stimuli : process
    begin
        -- Inicializace
        btn_up <= '0'; btn_down <= '0'; btn_right <= '0'; btn_left <= '0';
        rst <= '1';
        wait for 200 ns;
        rst <= '0';
        wait for 200 ns;

        -- 1. TEST: Pohyb DOPRAVA (A -> A na další anodě)
        -- Předpokládáme, že startovní stav je A a anoda first
        btn_right <= '1';
        wait for 5 * TbPeriod; -- Počkáme na několik taktů clk_en
        btn_right <= '0';
        wait for 10 * TbPeriod;

        -- 2. TEST: Pohyb DOLEVA (Návrat na předchozí anodu)
        btn_left <= '1';
        wait for 5 * TbPeriod;
        btn_left <= '0';
        wait for 10 * TbPeriod;

        -- 3. TEST: Pohyb DOLŮ ze segmentu A
        -- Aby fungovala tvoje logika (porovnání save_an), 
        -- musí mít had aspoň dva články nebo historii pohybu.
        btn_down <= '1';
        wait for 5 * TbPeriod;
        btn_down <= '0';
        
        -- Necháme simulaci běžet, abychom viděli výsledek v waveforu
        wait for 100 * TbPeriod;

        TbSimEnded <= '1';
        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_main of tb_main is
    for tb
    end for;
end cfg_tb_main;