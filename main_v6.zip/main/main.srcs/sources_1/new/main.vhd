library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity main is
    Port ( clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           btn_up : in STD_LOGIC;
           btn_down : in STD_LOGIC;
           btn_right : in STD_LOGIC;
           btn_left : in STD_LOGIC;
           data : out STD_LOGIC_VECTOR(6 downto 0));
end main;

architecture Behavioral of main is

    component clk_en is
        generic ( G_MAX : positive );
        port (
            clk : in  std_logic;
            rst : in  std_logic;
            ce  : out std_logic
        );
    end component clk_en;
    
    component debounce is
        port ( clk : in std_logic;
            rst : in std_logic;
            btn_in : in std_logic;
            btn_state : out std_logic;
            btn_press : out std_logic;
            btn_release: out std_logic);
    end component debounce;
    
    component counter is
        generic ( G_BITS : positive := 3 );  --! Default number of bits
        port (
            clk : in  std_logic;                             --! Main clock
            rst : in  std_logic;                             --! High-active synchronous reset
            en  : in  std_logic;                             --! Clock enable input
            cnt : out std_logic_vector(G_BITS - 1 downto 0));
    end component counter;    
    
    constant C_MAX : positive := 2;
    
    signal sig_press_up : std_logic;
    signal sig_press_down : std_logic;
    signal sig_press_right : std_logic;
    signal sig_press_left : std_logic;
    
    signal sig_direction_up : std_logic;
    signal sig_direction_down : std_logic;
    signal sig_direction_right : std_logic;
    signal sig_direction_left : std_logic;
    
    signal sig_cnt : std_logic_vector(5 downto 0);
    signal sig_ce_sample : std_logic;
     
    type state_reg is array (0 to 6) of integer range 0 to 7;
    signal sig_state_reg : state_reg;
    signal current_position : integer range 0 to 6 := 0;
    signal next_position : integer range 0 to 6 := 0;
    signal previous_position : integer range 0 to 6 := 0;        
    signal length : integer range 1 to 7 := 1;
          
begin

    debounce_0 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_up,
            btn_press => sig_press_up
        );

    debounce_1 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_down,
            btn_press => sig_press_down
        );

    debounce_2 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_right,
            btn_press => sig_press_right
        );
        
    debounce_3 : debounce
        port map (
            clk => clk,
            rst => rst,
            btn_in => btn_left,
            btn_press => sig_press_left
        );

    clock_0 : clk_en
        generic map ( G_MAX => C_MAX )
        port map (
            clk => clk,
            rst => rst,
            ce  => sig_ce_sample
        );
                         
    counter_0 : counter
        generic map ( G_BITS => 6 )
        port map (
            clk => clk,
            rst => rst,
            cnt => sig_cnt,
            en => sig_ce_sample
        );
        
    direction : process (clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                sig_direction_up    <= '0';
                sig_direction_down  <= '0';
                sig_direction_left  <= '0';
                sig_direction_right <= '0'; 
            elsif sig_press_up = '1' and sig_direction_down = '0' then
                sig_direction_up <= '1';
                sig_direction_down <= '0';
                sig_direction_right <= '0';
                sig_direction_left <= '0';
            elsif sig_press_down = '1' and sig_direction_up = '0' then
                sig_direction_up <= '0';
                sig_direction_down <= '1';
                sig_direction_right <= '0';
                sig_direction_left <= '0';
            elsif sig_press_right = '1' and sig_direction_left = '0' then
                sig_direction_up <= '0';
                sig_direction_down <= '0';
                sig_direction_right <= '1';
                sig_direction_left <= '0';
            elsif sig_press_left = '1' and sig_direction_right = '0' then
                sig_direction_up <= '0';
                sig_direction_down <= '0';
                sig_direction_right <= '0';
                sig_direction_left <= '1';
            end if;
        end if;
    end process direction;

    movement : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                current_position <= 0;
                -- sig_state_reg <= 
                previous_position <= 5;
                next_position <= 1;
                length <= 1;
            elsif sig_ce_sample = '1' then
            
                case current_position is
                    when 0 =>
                        if sig_direction_down = '1' then
                            if previous_position = 5 then
                                next_position <= 1;                                 
                            elsif previous_position = 1 then
                                next_position <= 5;
                            else
                                next_position <= current_position; 
                            end if;
                        end if;            
                    when 1 =>
                        if sig_direction_down = '1' then
                            next_position <= 2;
                        elsif sig_direction_left = '1' then 
                            if previous_position = 0 then
                                next_position <= 6;
                            elsif previous_position = 2 or previous_position = 6 then
                                next_position <= 0;
                            else
                                next_position <= current_position;
                            end if;                                   
                        end if;                        
                    when 2 =>
                        if sig_direction_left = '1' then
                            if previous_position = 1 or previous_position = 6 then
                                next_position <= 3;
                            elsif previous_position = 3 then
                                next_position <= 6;
                            end if;
                        elsif sig_direction_up = '1' then
                            next_position <= 2;
                        else
                            next_position <= current_position;
                        end if;
                    when 3 =>
                        if sig_direction_up = '1' then
                            if previous_position = 4 then
                                next_position <= 2;
                            elsif previous_position = 2 then
                                next_position <= 4;
                            else
                                next_position <= current_position;
                            end if;
                        end if;
                    when 4 =>
                        if sig_direction_up = '1' then
                            next_position <= 5;
                        elsif sig_direction_right = '1' then
                            if previous_position = 3 then
                                next_position <= 6;
                            elsif previous_position = 5 or previous_position = 6 then
                                next_position <= 3;
                            else
                                next_position <= current_position;
                            end if;
                        end if;
                    when 5 =>
                        if sig_direction_down = '1' then
                            next_position <= 4;
                        elsif sig_direction_right = '1' then
                            if previous_position = 0 then
                                next_position <= 6;
                            elsif previous_position = 4 or previous_position = 6 then
                                next_position <= 0;
                            else
                                next_position <= current_position;
                            end if;
                       end if;
                    when 6 =>
                        if sig_direction_up = '1' then
                            if previous_position = 1 or previous_position = 2 then
                                next_position <= 5;
                            elsif previous_position = 4 or previous_position = 5 then
                                next_position <= 1;
                            end if;    
                        elsif sig_direction_down = '1' then
                            if previous_position = 1 or previous_position = 2 then
                                next_position <= 4;
                            elsif previous_position = 4 or previous_position = 5 then
                                next_position <= 2;
                            else
                                next_position <= current_position;
                            end if;
                        end if; 
                end case;            
            
                for i in 0 to 6 loop
                    if i = next_position then
                        sig_state_reg(i) <= length;
                    elsif sig_state_reg(i) > 0 then
                        sig_state_reg(i) <= sig_state_reg(i) - 1;
                    end if;
                end loop;
                previous_position <= current_position;
                current_position <= next_position;
            end if;
        end if;
    end process movement;
    
    data_output : process(sig_state_reg)
    begin
        for i in 0 to 6 loop
            if sig_state_reg(i) > 0 then
                data(i) <= '1';
            else 
                data(i) <= '0';
            end if;
                
        end loop;
    end process data_output;
end Behavioral;